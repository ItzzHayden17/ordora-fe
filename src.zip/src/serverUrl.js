// const serverUrl = "http://localhost:8080"

//LocalEnvironemnt
const serverUrl = "https://pink-clubs-hunt.loca.lt"


export default serverUrl


